import java.util.Scanner;

class exercicio01 {
    
    public static void main(String[] args){

     //Construa um programa que exiba os valores entre dois números informados pelo usuário.

    int num1, num2;
    Scanner s = new Scanner(System.in);

    
 }
}