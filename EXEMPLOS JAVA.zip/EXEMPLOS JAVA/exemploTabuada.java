
import java.util.Scanner;

class exemploTabuada{
   
   public static void main(String[] args){


   //Pedir um número e exibir a tabuada desse número de 1 a 10
   //Divisao de um problema em partes
   //Passo 1 Definir as variáveis e seus tipos
   //Passo 2 Obter os valores para as variáveis (pedir ao usuário ou informar)
   //Passo 3 Fazer os cálculos necessários
   //Passo 4 Mostrar os resultados

   int num;
   Scanner s = new Scanner(System.in);

   System.out.print("Informe um numero para calcular a tabuada:");
   num = s.nextInt();

   System.out.println("\nTabuada do " + num + ": ");
   for(int i = 1; i <=10; i++){
      System.out.println(num + " X " + i + " = " + (num*i));
   }

   System.out.println("\nTabuada do " + num + ": ");
   for(int i = 1; i <=10; i++){
      System.out.printf("%d X %d = %d\n", num, i, (num*i));
   }

}
}