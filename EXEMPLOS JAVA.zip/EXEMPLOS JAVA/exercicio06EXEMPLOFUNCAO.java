import java.util.Scanner;

class exercicio06EXEMPLOFUNCAO {
    public static void main(String[] args){
 //Tendo como dados de entrada a altura, o peso e o sexo de uma pessoa, 
 //construa um algoritmo que calcule seu peso ideal, usando as fórmulas 
 //abaixo e exiba se a pessoa está abaixo, no peso ou acima do peso ideal.

 double num1, num2, resultado=0;
 char operador;
 Scanner s = new Scanner(System.in);

 System.out.print("Informe o primeiro numero: ");
 num1 = s.nextDouble();

 System.out.print("Informe o segundo numero: ");
 num2 = s.nextDouble();

 System.out.print("Informe o operador aritimetico (+, -, *): ");
 operador = s.next().charAt(0);

 switch (operador) {
    case '+'://chamei a função primeiro colcando: soma(num1, num2) ao invéz de por a conta.
    resultado = soma(num1, num2);
    break;

    case '-':
    resultado = subtracao(num1, num2);
    break;

    case '/':
    resultado = divisao(num1, num2);
    break;

    case '*':
    resultado = multiplicacao(num1, num2);
    break;

    default:
    System.out.println("Operador Invalido!");
}
   System.out.print("Resultado: " + num1 + " " + operador + " " + num2 + " " + "=" + " " + resultado);
}
                          //dentro dos parênteses são os parâmetros, ou seja deve ter na função, 
                          //e pode por outros nomes também as variáveis.
public static double soma(double num1, double num2){
   return num1 + num2;//return o que vai voltar, a conta o que ela vai fazer ao ser executada, tem que usar os parâmetros.

}
public static double subtracao(double num1, double num2){
   return num1 - num2;
}

public static double divisao(double num1, double num2){
   if (num2 == 0){
      return 0;
   }else{
      return num1 / num2;
   }
}
   public static double multiplicacao(double num1, double num2){
      return num1 * num2;
   }
}