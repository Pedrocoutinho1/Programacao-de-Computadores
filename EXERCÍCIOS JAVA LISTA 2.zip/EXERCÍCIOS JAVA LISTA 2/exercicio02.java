import java.util.Scanner;


class exercicio02{
   
    public static void main(String[] args){


        //declaracao de variaveis
        double Horas;
        double ValorPorHora;
        String mes;
        String nome;

        Scanner s = new Scanner(System.in);

        //solicitando dados para o usuario

        System.out.println("Informe seu nome:");
        nome  = s.nextLine();

        System.out.println("Informe tanto de horas trabalhadas:");
        Horas  = s.nextDouble();

        System.out.print("Informe o valor do ganho por hora trabalhada:");
        ValorPorHora  = s.nextDouble();

        System.out.print("Informe o mes trabalhado:");
        mes  = s.nextLine();
    }
}