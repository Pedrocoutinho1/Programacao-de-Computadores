import java.util.Scanner;

class exercicio06 {
    public static void main(String[] args){
      //Faça um algoritmo que receba dois valores e um operador aritmético (+, -, /, * - adição, subtração, divisão e multiplicação). 
      //Caso o símbolo seja outro, informe “Símbolo inválido”. 
      //Faça o cálculo conforme o operador informado e exiba a expressão e o resultado.
 double num1, num2, resultado=0;
 char operador;
 Scanner s = new Scanner(System.in);

 System.out.print("Informe o primeiro numero: ");
 num1 = s.nextDouble();

 System.out.print("Informe o segundo numero: ");
 num2 = s.nextDouble();

 System.out.print("Informe o operador aritimetico (+, -, *): ");
 operador = s.next().charAt(0);

 switch (operador) {
    case '+':
    resultado = num1 + num2;
    break;

    case '-':
    resultado = num1 - num2;
    break;

    case '/':
    resultado = num1 / num2;
    break;

    case '*':
    resultado = num1 * num2;
    break;

    default:
    System.out.println("Operador Invalido!");
}
   System.out.print("Resultado: " + num1 + " " + operador + " " + num2 + " " + "=" + " " + resultado);
}
}