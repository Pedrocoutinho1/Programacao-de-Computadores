import java.util.Scanner;


class exercicio03{
   
    public static void main(String[] args){

        //Escreva um algoritmo que leia três valores diferentes e os escreva em ordem crescente. Utilize uma seleção encadeada.

        //declaracao de variaveis
        int A;
        int B;
        int C;
        Scanner s = new Scanner(System.in);

        //solicitanto dados para o usuario

        System.out.println("Insira o primeiro valor: ");
        A = s.nextInt();

        System.out.println("Insira o segundo valor: ");
        B = s.nextInt();

        System.out.println("Insira o terceiro valor: ");
        C = s.nextInt();
        
        //calculos

        if (A < B && A < C){
            if (B < C){
                System.out.print("Ordem Crescente: " + A + "," + B + "," + C + ".");
            }else {
                System.out.print("Ordem Crescente: " + A + "," + C + "," + B + ".");
            }
        } else if (B < A && B < C) { // B é o menor
            if (A < C) {
                System.out.println("Ordem crescente: " + B + ", " + A + ", " + C);
            } else {
                System.out.println("Ordem crescente: " + B + ", " + C + ", " + A);
            }
        } else { // Se não foi A nem B, então C é o menor
            if (A < B) {
                System.out.println("Ordem crescente: " + C + ", " + A + ", " + B);
            } else {
                System.out.println("Ordem crescente: " + C + ", " + B + ", " + A);
            }
        }
        
    }
}