// Função para simular a navegação dos botões
function abrirPagina(url) {
    // Nesta fase, apenas um alerta para mostrar que o botão funciona.
    // Quando você tiver as outras páginas (html), você mudará esta linha para:
    // window.location.href = url;

    console.log(`Tentando navegar para: ${url}`);
    alert(`Página de destino: "${url}"\nFunção de navegação simulada. Você pode implementar a navegação real quando criar a página.`);
}

// Exemplo de código JS, caso você queira adicionar alguma funcionalidade mais complexa (opcional)
document.addEventListener('DOMContentLoaded', () => {
    // Código para inicializar algo após o carregamento da página
    console.log('Cartilha Artistas X IA carregada com sucesso!');
});